<?php defined('_JEXEC') or die('Restricted access'); ?>
<h3>Dit is het antwoord</h3>