<?php
/**
 * Availability Calendar Install Script
 * 
 * @package    	com_availcal
 * @subpackage 	components
 * @link 				
 * @license			GNU/GPL
 */

	function com_install()
	{
		// Execute some code here
		// <code>
		
		echo "<p>Thank you for installing the Availability Calendar.</p>";
		
		return true;
	}
?>