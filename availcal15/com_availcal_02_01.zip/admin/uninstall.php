<?php
/**
 * Availability Calendar uninstall Script
 * 
 * @package    	com_availcal
 * @subpackage 	components
 * @link 				
 * @license			GNU/GPL
 */

	function com_uninstall()
	{
		// Execute some code here
		// <code>
		
		echo "<p>We are sorry that you found it necessary to uninstall the Availability Calendar.</p>";
		
		return true;
	}
?>